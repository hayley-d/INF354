﻿using Microsoft.AspNetCore.Identity;

namespace Assignment3_API.Models
{
    public class AppUser: IdentityUser
    {

    }
}
